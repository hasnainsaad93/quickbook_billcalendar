﻿/// <reference path="jquery-3.3.1.js" />
/// <autosync enabled="true" />
/// <reference path="respond.js" />
/// <reference path="respond.matchmedia.addlistener.js" />
/// <reference path="npm.js" />
/// <reference path="bootstrap.min.js" />
/// <reference path="modernizr-2.8.3.js" />
